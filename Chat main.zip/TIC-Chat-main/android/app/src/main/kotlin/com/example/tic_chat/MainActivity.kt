package com.example.tic_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
